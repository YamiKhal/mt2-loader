# Writing plugins for the MT2 Loader

A **plugin** is a small Windows DLL, written in C++, that runs inside MMORPG Tycoon 2. It can change what any function in the game does: run code before or after it, replace it, or change one call, text or number inside it. That reaches everything data files can't, like hard-coded rules and limits.

You say *what* to change, in one line; the loader finds the place in the game's code, checks it, changes it, and undoes it if anything doesn't fit:

```cpp
game::in("mmoCharacter::EquipWeaponModel").call("std::operator==").with_text("humanoid").returns(true);
```

This guide goes from an empty computer to a working plugin, then covers the whole API. How the loader works inside is in [LOADER.md](LOADER.md); how the mod manager handles plugin mods is in [mt2-modmanager/docs/MODDING.md](mt2-modmanager/docs/MODDING.md#native-plugins-mt2-loader).

**Status (loader 0.8.1, 2026-09-27):** plugins are written in C++ against `mt2loader.hpp`. Changing functions, calls, texts and numbers by name (`game::in`), calling game functions, the game's objects by their names (fields, managers, lists, enums), the plugin's own values in saved games, game strings, settings and sharing work, tested on a fake game with plugins built by both GCC and Visual Studio, and offline against the real game's code. In the real game, test L2 passed (a hook by name); L3 and L4 are next. The API grows without breaking (see [Versions](#versions)).

**Example mods** in the SDK's `examples` folder:

- `hello_plugin`: the smallest plugin.
- **`weapons_any_rig`**: a real mod in two lines. Every character whose costume has a hand can hold a weapon, not only humanoids. [Section 8](#8-a-real-example-weapons-on-any-rig) walks through it.
- **`top_spenders`**: a new tab in the Leaderboards window, the players who spent the most real money, with a checkbox in Design > Features. Data files and a plugin together. [Section 9](#9-a-bigger-example-a-new-leaderboard-tab).

---

## Contents

1. [What you need](#1-what-you-need)
2. [Your first plugin in five minutes](#2-your-first-plugin-in-five-minutes)
3. [The project](#3-the-project)
4. [How a plugin runs](#4-how-a-plugin-runs)
5. [Finding what to change](#5-finding-what-to-change)
6. [Changing the game: game::in](#6-changing-the-game-gamein)
7. [The rest of the API](#7-the-rest-of-the-api)
8. [A real example: weapons on any rig](#8-a-real-example-weapons-on-any-rig)
9. [A bigger example: a new leaderboard tab](#9-a-bigger-example-a-new-leaderboard-tab)
10. [Picked in the game, kept in the save: quest markers](#10-picked-in-the-game-kept-in-the-save-quest-markers)
11. [Going deeper](#11-going-deeper)
12. [Debugging](#12-debugging)
13. [Releasing your mod](#13-releasing-your-mod)
14. [Rules](#14-rules)
15. [When something goes wrong](#15-when-something-goes-wrong)
16. [Versions](#versions)
17. [Plain C](#plain-c)

---

## 1. What you need

| What | Why | Where |
|---|---|---|
| **MT2 Loader**, installed in the game | Runs plugins | MT2 Mod Manager: the **Install loader** button. Or by hand, from the loader's release zip |
| **The SDK** | The API header, the project template, and `mt2sdk` | `MT2LoaderSDK-<version>.zip`. In this repository, `mt2-loader/dist/sdk` after building the loader |
| **A C++20 compiler for 64-bit Windows** | Builds your DLL | One of the two below |

**Compiler, option A (easiest): Visual Studio Community** 2022 or newer. Free. In the Visual Studio Installer, tick the workload **Desktop development with C++**. It includes the compiler, CMake and a debugger. Nothing else to set up.

**Option B: MSYS2 MinGW-w64** (GCC 13 or newer). For people who prefer a terminal or VS Code. Install [MSYS2](https://www.msys2.org/), then in its terminal:

```text
pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-cmake mingw-w64-x86_64-ninja
```

clang 17 or newer works too. Whichever compiler you use, the plugin behaves the same: `mt2loader.hpp` takes care of everything where your compiler and the game's (GCC) differ ([section 10](#how-calls-to-the-game-work)).

**If you're new to C++:** a plugin needs little of it. Functions, variables, `if`, `for`, and lambdas (`[](int x) { return x + 1; }`, small functions written in place) cover everything in this guide. [learncpp.com](https://www.learncpp.com/) chapters 1 to 12 are more than enough.

## 2. Your first plugin in five minutes

1. **Make the project.** In the SDK folder, open a terminal (in Explorer: type `cmd` in the address bar) and run:

   ```text
   mt2sdk new MyPlugin "My Plugin"
   ```

   This makes the folder `MyPlugin` with a plugin that writes a line to the log when the title screen opens. It fills in the mod id (`myplugin`), the name, and your game's build.

2. **Build it.**
   - Visual Studio: **File > Open > Folder…**, pick `MyPlugin`, wait until the Output window says CMake is done, then **Build > Build All**.
   - MSYS2: `cd MyPlugin`, then `cmake -B build -G Ninja` and `cmake --build build`.

   The DLL lands in `MyPlugin\mod\native\`. The build then copies `mod\` into the game's mod folder, so the game finds it on its next start. (If the build says it can't find the game's mod folder, see [the project](#3-the-project).)

3. **Run it.** Start the game (Steam, or Launch in the mod manager). At the title screen, quit.

4. **Read the log:** `mt2loader\loader.log` in the game folder (in the mod manager: **Tools > Open loader log**):

   ```text
   [myplugin] starting native/myplugin.dll
   Readable names of the game's symbols ready (94 ms)
   [myplugin] Hooked mmoModeTitle::Init()
   [myplugin] Ready on game build 0.30.7
   Plugins: 1 started, from 3 mod folders
   [myplugin] The title screen is opening
   ```

That's the whole loop: change `src\plugin.cpp`, build, start the game, read the log. This is the plugin:

```cpp
#include <mt2loader.hpp>


void plugin::init() {
    // mmoModeTitle::Init runs when the title screen opens.
    game::in("mmoModeTitle::Init").before([](void* title) {
        plugin::log("The title screen is opening");
    });

    plugin::log("Ready on game build {}", plugin::game_build());
}
```

## 3. The project

```text
MyPlugin/
  CMakeLists.txt          the build; the mod id is at the top (MOD_ID)
  include/mt2loader.hpp   the API: the one header a plugin includes
  include/mt2loader.h     the C layer underneath it (never included directly)
  src/plugin.cpp          your code; every .cpp file in src/ is built in
  mod/                    the mod itself, exactly what players get
    manifest.json
    native/myplugin.dll   (made by the build)
```

**`mod/` is the mod.** Anything else your mod needs (textures, data files, a `config.json` for player settings) goes in there too, as for any other mod ([MODDING.md](mt2-modmanager/docs/MODDING.md)).

**More source files:** add `.cpp` and `.h` files to `src/` and build again; CMake picks them up. Every file that uses the API includes `<mt2loader.hpp>`; `plugin::init` is defined once, in any of them.

**Build options** (in Visual Studio: **Project > CMake Settings**, or `-D<option>=<value>` on the command line):

| Option | Default | What it does |
|---|---|---|
| `COPY_TO_GAME` | `ON` | After each build, copy `mod/` to `<game's mod folder>/<mod id>` |
| `GAME_MOD_FOLDER` | found by itself | The game's mod folder: `%APPDATA%\VectorStorm\MMORPG Tycoon 2\<Steam number>\mod`. Set it when you have more than one Steam account on the PC |

The copy fails while the game runs, because Windows locks the DLL. Close the game before building.

**Using the mod manager instead of the copy:** set `COPY_TO_GAME` to `OFF`, add `mod\` with **Tools > Add dev mod…**, and press its refresh button after each build. Don't use both for the same mod: the loader starts a mod id only once, from the first folder it finds.

**What the template sets up for you:** C++20, 64-bit only, and the C++ runtime linked into the DLL, so players need nothing else installed. The DLL is about 0.4 MB from Visual Studio and 1.2 MB from GCC.

### manifest.json

```json
{
    "id": "myplugin",
    "name": "My Plugin",
    "version": "1.0.0",
    "author": "",
    "description": "",
    "loader": {
        "plugins": ["native/myplugin.dll"],
        "libraries": [],
        "game_builds": ["0.30.7"]
    }
}
```

| Field | Meaning |
|---|---|
| `id` | 2-24 characters: `a-z`, `0-9`, `_`, starting with a letter. Your plugin's name in the log, and the prefix of anything it shares |
| `loader.plugins` | DLLs the loader starts. Paths inside the mod, with `/` |
| `loader.libraries` | Other DLLs your plugin loads (say, a library you use). Put them next to the plugin: Windows looks there |
| `loader.game_builds` | The game builds you tested on. On any other build, your plugin doesn't start and the log says why. `mt2sdk build` tells you yours |

The other fields are the same as for every mod ([MODDING.md, manifest.json](mt2-modmanager/docs/MODDING.md#manifestjson)).

## 4. How a plugin runs

```cpp
#include <mt2loader.hpp>


void plugin::init() {
    plugin::log("Hello from {}", plugin::id());
}
```

1. The game starts. The loader waits until it's past its copy protection (Steam's DRM).
2. The game sets up its files, and just before it looks at its mods, the loader starts the plugins: for each mod folder in order, `plugin::init` of each plugin it lists. **No game system exists yet**: no window, no data, no world. It's the moment to say what to change, not to use the game.
3. When every plugin's `init` has run, the steps plugins gave to `plugin::on_ready` run. That's where you look up what other plugins shared.
4. From then on, your code runs whenever the game reaches something you changed.

**When something fails in `init`,** the plugin doesn't start, and nothing it did stays. Anything in the API that can't do its job (a name that isn't in the game, a call that isn't there, a text used in three places when you meant one) throws a `plugin::Error`; so does `plugin::fail("reason")`. The loader then undoes every change your `init` made, and the log says why:

```text
[myplugin] Not started: mmoCharacter::EquipWeaponModel(bool) has no call to std::operator== with the text "humanoid". Its 1 change is undone
```

So `init` can be written straight down, without checking every step: it either works completely, or leaves the game as it was. If you want to go on without an optional part, catch the error yourself.

**Global variables** are made when Windows loads the DLL, before `init`, while the API isn't there yet. A `game::Function` declared outside a function is fine: it's looked up when the plugin starts. Anything else that uses the game belongs inside `init` or later.

Plugins are never unloaded.

## 5. Finding what to change

The game ships with a table of every function and global it has: **about 100,000 names**, like `mmoCharacter::EquipWeaponModel(bool)`. That's what makes this work: you name the function you want to change, and the name stays the same across game updates even when its code moves.

**`mt2sdk find`** searches them. All the words must appear, in any case. With `--cpp`, each comes with a declaration to paste into your plugin:

```text
> mt2sdk find equip weapon --cpp
mmoCharacter::EquipWeaponModel(bool)    0x1403a1df0
    game::Function<RESULT(void* object, bool)> equip_weapon_model{"mmoCharacter::EquipWeaponModel(bool)"};
1 found. Use a name as it's written here, with or without its (parameters)
RESULT is the function's return type, which a name doesn't include: see its code (in Ghidra or x64dbg).
For a static function, leave out the object. Details: LOADER_MODDING.md, section 7 (game::Function)

> mt2sdk find costumeeditor setup
mmoCostumeEditorView::_SetupPrefabList()    0x1406b2640
mmoCostumeEditorView::SetupFor(mmoCharacterType*)    0x1406b4500
2 found. Use a name as it's written here, with or without its (parameters)
```

The parameters it shows are also the ones your lambdas take ([section 6](#6-changing-the-game-gamein)).

**`mt2sdk symbols`** writes all of them to `game_symbols.txt`, to browse in any editor. The address is where the function sits in `MT2.exe` as disassemblers show it.

**Reading what a function does.** A name tells you where to look; to know what the function does, what it calls, which texts and numbers it uses, and what it returns, read its code:

- [Ghidra](https://ghidra-sre.org/) (free): load `MT2.exe`, go to the address from `mt2sdk find` (press G). The decompiler shows C-like code, including the return type, the calls and the texts.
- [x64dbg](https://x64dbg.com/) (free): attach to the running game, break on a function, and watch its arguments.
- In this repository, `tools/re/mtre.py dis <name>` prints a function's code with the names of what it calls and the texts it uses.

**The game's own names help a lot:**

| Prefix | What it is |
|---|---|
| `mmo…` | The game: `mmoCharacter`, `mmoCostumeEditorView`, `mmoModeTitle` (the title screen), `mmoGame` |
| `vs…` | The engine, VectorStorm. Mostly [public](https://github.com/vectorstorm/vectorstorm): read the source to see what a `vs` function does |
| `…::Init`, `Deinit`, `Update(float)` | Called when something starts, stops, and every frame |
| `vtable for X` | The table of `X`'s virtual functions |
| `X::s_instance` | The one object of a manager class |

Findings about the game's code so far: [LOADER.md](LOADER.md) §2.3 (the layouts of game objects that are known) and §3, [FINDINGS.md](FINDINGS.md), and the `archive/` folder.

## 6. Changing the game: game::in

`game::in("name")` picks a game function. Then you say what to change: the function as a whole, or one call, text or number inside it. (If you know Minecraft modding: these are mixins. `before` is an inject at the head, `after` at the return, a `call(...)` a redirect, `text` and `number` a constant change.)

### The whole function

```cpp
// Runs first, with the function's arguments; then the game's function runs as usual.
game::in("mmoCharacter::EquipWeaponModel").before([](void* character, bool show) {
    plugin::log("A character equips a weapon");
});

// Runs after it, with its result first, and returns the result the game gets.
game::in("mmoCharacter::EquipWeaponModel").after([](int result, void* character, bool show) {
    return result;
});

// Runs instead of it.
game::in("mmoCharacter::EquipWeaponModel").replace([](void* character, bool show) {
    return 0;
});

// It returns this, without running.
game::in("mmoCharacter::CanSwim").returns(true);   // a made-up name
```

**The lambda's parameters are the function's parameters**, written with their types, the object first for a method: `void* character` for the game's objects (`const void*` for a `const` method), `bool`, `int`, `float` as the game has them, `const game::String&` for a `std::string`. `mt2sdk find` shows them. The loader reads them from your lambda, so it knows how to call it; that's why they need their types, not `auto`. Name them as you like; leave out the name of one you don't use, or keep it for readability.

**`after` gets the result first** and returns the one to use: `[](int result, void* character, bool show) { return result + 1; }`. For a function that returns nothing, the lambda takes just the parameters and returns nothing.

**`before`** doesn't need to know what the function returns, so it's the easy way to react to something. One exception: for a function that returns a class (a `std::string`, a `vsVector3D`), the game passes a hidden result pointer first, so use `after` there.

### A call inside it

```cpp
game::in("mmoCharacter::EquipWeaponModel").call("std::operator==").with_text("humanoid").returns(true);
```

`call("name")` picks a call the function makes to another function, named as `mt2sdk find` shows it, with or without parameters (a template's return type and `<...>` can be left out: `std::operator==` finds `bool std::operator==<char, …>(std::string const&, char const*)`). Only that one call changes; every other place that calls the same function doesn't.

**Picking the right call:** the function must make exactly one such call, or you say which:

| Add | Picks |
|---|---|
| `.with_text("humanoid")` | The call that's passed this text (the text is used just before it) |
| `.nth(2)` | The second one, counting from 1 |
| `.every()` | All of them |

If it isn't clear which one you mean, the plugin doesn't start, and the log says what's there: `mmoCharacter::EquipWeaponModel(bool) has 3 calls to std::operator== (at +0x5a, +0x9c, +0x120): pick one with .nth(1) to .nth(3), or all of them with .every()`.

Then, as for a whole function, with the called function's parameters and result: `.returns(value)`, `.replace(...)`, `.before(...)`, `.after(...)`:

```cpp
game::in("mmoCharacter::EquipWeaponModel").call("std::operator==").with_text("humanoid")
    .replace([](const game::String& rig, const char* name) {
        return rig == "humanoid" || rig == "dragon";
    });
```

### A text or a number inside it

```cpp
game::in("mmoCostumeEditorView::_UpdateGrid").text("not humanoid").becomes("no weapons on this rig");
game::in("mmoGuild::CanHire").number(8).becomes(16);    // a made-up name
```

- **`text("…").becomes("…")`** changes a text the function uses (the whole text, not part of it). The new one can be longer; it gets its own memory near the game's code. If the game uses the text's length right next to it, the loader refuses a new length and says so, because the game would cut the text short or read past it.
- **`number(8).becomes(16)`** changes a number written in the function's code, like the 8 in `if (count < 8)`. Only numbers the code uses, not its own stack bookkeeping. The new number must fit where the old one was (the log says the range if it doesn't).

Both pick exactly one place too, unless `.nth(n)` or `.every()` says otherwise.

**Everything returns a handle** (`game::Hook` or `game::Patch`) whose `remove()` or `undo()` takes the change out again. You don't need to keep it: changes stay until the game exits.

**Several plugins can change the same function or call:** the newest runs first, and each one leads to the one before it. Every change is in the log: `[yourmod] Hooked the call at mmoCharacter::EquipWeaponModel(bool)+0x5a`, `The number 8 in mmoGuild::CanHire() is now 16`.

**If your lambda throws** while the game runs, the log says so (once), and the game's own code runs instead. The game never sees a C++ exception.

**Keep lambdas fast** when the game calls them often (anything with `Update` or `Draw` in its name runs every frame). One lambda can be used in up to 32 places (a loop over functions, `.every()`).

## 7. The rest of the API

### The plugin namespace

| Name | What it does |
|---|---|
| `void plugin::init()` | Yours to write: what the plugin does when the game starts ([section 4](#4-how-a-plugin-runs)) |
| `plugin::log("Found {} weapons", count)` | One line in `mt2loader\loader.log`, with `[your mod id]` and the time in front. [`std::format`](https://en.cppreference.com/w/cpp/utility/format/spec) style: `{}` for each value, `{:x}` for hex |
| `plugin::fail("{} is missing", name)` | Stops what the plugin is doing, with a reason for the log. In `init`: the plugin doesn't start, and its changes are undone. In a lambda the game runs: the game's own code runs instead |
| `plugin::on_ready(callback)` | Runs `callback` once every plugin's `init` has run |
| `plugin::id()`, `plugin::game_build()`, `plugin::loader_version()` | Your mod's id, the game build (`"0.30.7"`), the loader's version |
| `plugin::folder()` | Your mod's folder, to read your own files: `plugin::folder() / "config.json"` |
| `plugin::setting<T>("key")` | A setting your mod declares in `config.json`, as the player set it in the mod manager, [below](#settings-the-player-picks-configjson) |
| `plugin::Remembered<T>` | A value the plugin changes and keeps between sessions, [below](#values-the-plugin-remembers) |
| `plugin::data_folder()` | A folder for your plugin's own files that stays when the mod is updated: `<the game's user folder>\mt2loader\<mod id>` |
| `plugin::share(name, pointer)`, `plugin::shared<T>(name)` | Sharing between plugins, [below](#sharing-between-plugins) |

The log is replaced every launch; the one before is kept as `loader.previous.log`.

### Calling game functions: game::Function

Write the function's type (its result, then its parameters, as for the lambdas above) and call it like any function:

```cpp
game::Function<int(void* character, bool show)> equip_weapon{"mmoCharacter::EquipWeaponModel"};

equip_weapon(character, true);
```

| In the game | As a `game::Function` type |
|---|---|
| `void mmoModeTitle::Init()` | `void(void* title)` |
| `int mmoCharacter::EquipWeaponModel(bool)` | `int(void* character, bool show)` |
| `float Thing::Scale(float) const` | `float(const void* thing, float value)` |
| `void* vsSingletonManager::GetSingleton(const std::string&)` | `void*(void* manager, const game::String& name)` |
| `std::string Thing::Name() const` | `game::String(const void* thing)` |
| `const std::string& mmoTextEditPane::GetText() const` | `const game::String&(const void* field)` |
| `vsVector3D mmoProp::GetFocusPosition() const` | `Vector3(const void* prop)`, with `struct Vector3 { float x, y, z; };` |
| `const vsColor& mmoColorPicker::GetColor()` | `const Color&(void* picker)`, with `struct Color { float red, green, blue, alpha; };` |
| a `static` function, or one outside a class | its parameters, with no object |

A `game::Function` declared outside any function is looked up when the plugin starts, and a missing name stops the plugin there. `mt2sdk find --cpp` writes the declaration for you, except the result type, which the name doesn't include.

**Check the result type**, since nothing else can. A getter often hands back its own member as a reference (`const T&`) instead of a copy, and the two are called differently: for a class or a struct bigger than 8 bytes returned by value, the caller passes a place to put it first, so declaring a reference function as returning by value makes the game read that place as its object. In the disassembly (`mtre.py dis`, or Ghidra), a function that ends with `lea rax, [rcx + …]; ret` returns a reference to its own member; one that writes through `rcx` and gets its object in `rdx` returns by value. The quest markers example ran into this with `mmoColorPicker::GetColor`.

**Call at the right time.** In `init`, the game has made nothing yet: call game functions from your lambdas, once the game is running, on objects you get from the game ([the game's objects](#the-games-objects-fields-managers-lists)).

### game::String

The game passes text around as C++ `std::string`, compiled by GCC. Visual Studio's `std::string` is a different thing, so the game's is **`game::String`**. It converts to and from `std::string`, `std::string_view` and text, so you can mostly forget about it:

```cpp
game::String name = get_name(character);        // a game function that returns a std::string
plugin::log("Name: {}", name);
std::string copy = name.str();

has_thing(manager, "dragon");                   // a game function that takes const std::string&
```

Its memory is on the game's heap, so the game can keep a `game::String` you give it, or free it. Make them inside functions: a long one can't be made before the plugin starts. A lambda that returns one writes `-> game::String`; using `std::string` where the game has one doesn't compile, with a message saying so.

### The game's objects: fields, managers, lists

The game keeps a name for every field it saves, and knows where it is. So a field is read and changed by that name, the class's and the field's, in place:

```cpp
int spent = game::field<int>(subscriber, "mmoSubscriber::spend_other");
void* toon = game::field<void*>(subscriber, "mmoSubscriber::main");
game::field<game::String>(toon, "mmoToon::name") = "Renamed";
```

- **Where the names are:** `mt2sdk find "mmoSubscriber::s_"` lists a class's saved fields (`mmoSubscriber::s_spend_otherProperty` is the field `spend_other`). A field of a class it's built on works through it too: `name` belongs to `mmoProp`, and `"mmoToon::name"` finds it.
- **Types are checked** against the game's: reading an `int` as a `float` stops with `mmoSubscriber::spend_other is of type int in the game: read it as game::field<int>`. Text is `game::String`, a pointer to another object is `void*`, a list of objects is `game::Objects`.
- **It keeps working after a game update** that moves fields around, since the game says where they are.
- Only saved fields have names. For others, `game::field<int>(object, 0x4b0)` takes an offset (collected in LOADER.md §2.3); a wrong one crashes, as it would in the game.

**The game's managers** are its singletons, reached by class name. `nullptr` while there's none, as before a game is loaded:

```cpp
void* subscribers = game::singleton("mmoSubscriberManager");
```

**Lists of objects** (the engine's object arrays) are `game::Objects`, for a `for` loop:

```cpp
for (void* subscriber : game::field<game::Objects>(subscribers, "mmoSubscriberManager::subscriber")) {
    plugin::log("Spent: {}", game::field<int>(subscriber, "mmoSubscriber::spend_other"));
}
```

**New objects**, made the way the game makes the ones it loads from its files, and deleted with their own destructor:

```cpp
void* board = game::create("mmoLeaderboard");
game::destroy(board);
```

### The game's enums: game::enumeration

Data files write enums as words (`type "gold";`). A word's value, and a new word:

```cpp
int leaderboards = game::enumeration("mmoGameFeatures::Flag").value("Leaderboards");

game::enumeration("mmoLeaderboard::Type").add("spenders", 100);
```

`add` teaches the game a word: where it reads that enum from a data file, `"spenders"` gives 100, where the game would otherwise have refused the word. Pick a value the game doesn't use, and handle it in your hooks: the game's own code only knows its own values ([section 9](#9-a-bigger-example-a-new-leaderboard-tab) does). The log says `mmoLeaderboard::Type reads "spenders" as 100`.

### Settings the player picks: config.json

Anything a player might want different (a limit, what counts, whether something shows) is a setting, not a number in your code. Declare it in your mod's `config.json`, the mod manager's settings format ([MODDING.md](mt2-modmanager/docs/MODDING.md#player-settings-configjson)):

```json
[
  { "key": "minimum_spend", "label": "Minimum spend", "type": "int", "default": 1, "min": 1, "max": 100000 },
  {
    "key": "counted", "label": "Spending counted", "type": "choice", "default": "lifetime",
    "options": [{ "value": "lifetime", "label": "Everything" }, { "value": "purchases", "label": "Purchases only" }]
  }
]
```

and read it in the plugin:

```cpp
int minimum = plugin::setting<int>("minimum_spend");
std::string counted = plugin::setting<std::string>("counted");
```

The manager shows each setting on the mod's **Details** tab (with its label, slider or list), keeps the player's value per mod profile, and puts it next to your plugin when it deploys. Without the manager, the defaults apply. `bool` reads as `bool`, `int` as a whole number, `float` as `double`, `string`, `choice` and `color` as `std::string` (the choice's value; a color as `"#RRGGBB"`); another type stops with the one to use. Settings change when the player deploys, so read them once in `init`.

The same `config.json` can also fill `<key>` placeholders in your data files, so one setting can drive both.

### Values the plugin remembers

A value the plugin changes itself and keeps between sessions, like a choice the player makes in the game:

```cpp
plugin::Remembered<bool> show_spenders{"show_top_spenders", true};

if (show_spenders) { ... }
show_spenders = false;    // saved right away
```

`true`/`false`, a number or text (`std::string`), kept in `plugin::data_folder() / "remembered.txt"`, one `name = value` line each. The default is used until something is saved. The same for every saved game; for a value that belongs to one game, keep it in the saved game (next).

### Values in saved games: game::saved

Your own values on a game object, written into the saved game with it and read back when the save loads:

```cpp
game::Saved marker = game::saved(npc);

marker.set("shape", "star");
marker.set("uses", 3);

std::string shape = marker.get("shape", "game");    // the default when there's none
std::optional<int> uses = marker.find<int>("uses");
marker.erase("uses");

game::saved().set("visits", 12);    // on the saved game as a whole
```

- **Any object the game saves**: an NPC, a building, a toon, the game state. `game::saved()` with nothing is the saved game as a whole (the game state), while a game is open.
- **True/false, numbers and text.** Keys are 1 to 64 characters of `A-Z a-z 0-9 _ - .`. Each plugin sees only its own keys, so two mods can both use `"shape"`.
- **When they're there:** a value you set is saved with the object the next time the game saves. When a save loads, the values are back by the time the object's `PostResolve` runs, so hook that (or anything later) to act on them.
- **They go away with the object.** A new object never inherits values from one that was deleted.
- **Saves stay the game's.** Each object with values gets one more field, `mt2loader`, next to the game's own. The game's own fields are never changed. The game skips a field it doesn't know, so the save loads without the loader or without your mod. Saved again without the loader, the values are gone and the rest is as it was. With the loader but without your mod, they're kept.

Setting a value on something the game doesn't save stops with `the game doesn't save this object the usual way`. The log counts what each save and load carried (`Saved plugin values on 12 game objects`).

### Commands from the game's windows: game::Record

A button's `command "MessageTo Window QuestMarker shape star"` reaches the window's `UICommand` as a record: a label and the words after it.

```cpp
game::in("mmoNPCInfoWindow::UICommand").after([](bool handled, void* window, game::Record command) {
    if (command.label() != "QuestMarker") {
        return handled;
    }

    std::string what = command.text(0);    // "shape"; command.text(1) is "star", command.size() is 2
    ...
    return true;    // handled: the game looks no further
});
```

`number(i)` reads a word as a whole number (`std::optional<int>`). A record anywhere else in the game (a `vsRecord&` or `vsRecord*` parameter) works the same way.

### Sharing between plugins

Plugins can offer things to each other: a function, a table of functions, some data.

```cpp
// In the plugin that offers it, in init:
struct WingsApi {
    void (*add_wing)(void* character);
};

static WingsApi wings_api{ add_wing };
plugin::share("wings.api", &wings_api);

// In a plugin that uses it:
plugin::on_ready([] {
    auto* wings = plugin::shared<WingsApi>("wings.api");

    if (wings != nullptr) {
        wings->add_wing(character);
    }
});
```

Names are global: start them with your mod id. A name can be shared once; a second `share` of it fails and logs who has it. Share plain structs, function pointers and numbers: the plugin on the other side may be built by another compiler, so its `std::string` or `std::vector` isn't yours. Put the struct in a header that you publish with your mod, so others can use it.

## 8. A real example: weapons on any rig

`examples/weapons_any_rig` lets every character hold a weapon if its costume has a hand, not only characters on the `humanoid` rig. The whole plugin:

```cpp
#include <mt2loader.hpp>


void plugin::init() {
    game::in("mmoCharacter::EquipWeaponModel").call("std::operator==").with_text("humanoid").returns(true);
    game::in("mmoCostumeEditorView::_UpdateGrid").call("std::operator==").with_text("humanoid").returns(true);

    plugin::log("Any rig with a hand attachment can hold weapons");
}
```

**How it was found.** `mt2sdk find equip weapon` gives `mmoCharacter::EquipWeaponModel(bool)`. Its code (in Ghidra, or `mtre.py dis`) starts with the rig check:

```text
lea  rcx, [rsi+0x38]            the costume's rig name (a std::string)
lea  rdx, "humanoid"
call std::operator==(std::string const&, char const*)
test al, al
jne  <the weapon code>          only humanoids get past here
```

The weapon code then looks through the costume for an attachment point named `hand`, and attaches the weapon there. So there are two rules: the rig is humanoid, and the costume has a hand. The costume editor has the same pair (`mmoCostumeEditorView::_UpdateGrid`, which shows "Cannot use weapons: not humanoid" or "no hands").

**The smallest change:** make the compare against `"humanoid"` say yes, in both places. The hand rule stays, so rigs without a hand still get no weapon, and humanoids don't change. Each line says exactly that: in this function, the call to `std::operator==` that's passed `"humanoid"` returns `true`.

**What the loader does for it:** finds each function by name, finds the one call to that compare that's passed that text, redirects only that call, and checks everything first. After a game update that changes this code, the plugin doesn't start, the log says why, and the game runs unchanged. The log when it works:

```text
[weapons_any_rig] Hooked the call at mmoCharacter::EquipWeaponModel(bool)+0x5a
[weapons_any_rig] Hooked the call at mmoCostumeEditorView::_UpdateGrid()+0x89
[weapons_any_rig] Any rig with a hand attachment can hold weapons
```

**What counts as a hand.** An attachment point named `hand` in the costume, on any part. It's more than a bone: it holds the weapon's position and rotation. Humanoid costumes get theirs from their right arm's model (`mmoCostume::FixHandNode`). For another rig, add one to the part that should hold the weapon, in your mod's costume file. Not yet tried in game (LOADER.md §5.3); the format is the one vanilla humanoid costumes use:

```text
mmoCostumePartDescriptor {
    boneName "hand_right"
    modelFilename "costumes/dragon/hand_right.vmb"
    attachment {
        mmoCostumeAttachment {
            name "hand"
        }
    }
}
```

Its `offset` (translation and rotation, as in the vanilla humanoid costumes) places the weapon relative to that bone. Also give the rig the attack animations the weapons use (`attack_shot_*`, `attack_bow_*` for ranged weapons); the quadruped rig doesn't have them.

## 9. A bigger example: a new leaderboard tab

`examples/top_spenders` adds a **Spenders** tab to the Leaderboards window: the players who have spent the most real money on your game, as money in the player's currency. **Design > Features** gets a checkbox for it. It's a mod of both kinds: data files add the tab and the checkbox, and a plugin makes them work.

```text
mod/
  manifest.json
  config.json                     what counts as spent, and the least a player must have spent to be listed
  report_leaderboards.win         the tab: a leaderboard page like the game's own, with type "spenders"
  design_features.win             the checkbox, and the window made taller for it
  i18n/english/top_spenders.vrt   the tab's name, its title, the checkbox's label and description
  native/top_spenders.dll
```

The `.win` files hold only what the mod adds; MT2 Mod Manager merges them into the game's ([MODDING.md](mt2-modmanager/docs/MODDING.md#how-text-files-are-merged)). So add this mod in the manager, not by copying `mod/` into the game (the example's CMake project doesn't copy it, for that reason).

**How the game's leaderboards work** (found with `mt2sdk find Leaderboard` and the disassembly): the game keeps five leaderboards (quests, gold, level, kills, duels) in `mmoLeaderboardSet`, inside the saved game. Each tab is an `mmoLeaderboardView` whose `type` says which one it shows; every frame it asks `mmoLeaderboardSet::GetLeaderboard(type)` for it and draws its rows: rank, name, and the number through `vsFormatNumber`. A type the game doesn't know is `none`, and the view draws nothing. `mmoLeaderboardsWindow::OnShow` hides the Duels tab when PvP duels aren't researched, with `mmoMultiTabView::EnablePage`.

A sixth leaderboard in the saved game would make saves the game can't load without the mod. So the plugin makes its own, when it's asked for, from what the game already keeps: each subscriber's lifetime spend (`spend_subscriptions` and `spend_other`, the numbers the player info window adds up as "Lifetime spend"). Nothing is saved; removing the mod leaves the game as it was.

**The tab**, in five steps:

```cpp
game::enumeration("mmoLeaderboard::Type").add("spenders", top_spenders);

game::in("mmoLeaderboardSet::GetLeaderboard").after([](void* board, void*, int type) {
    return type == top_spenders ? top_spenders_board() : board;
});
```

1. The tab's `type "spenders"` now reads as `top_spenders` (100).
2. When the view asks for that leaderboard, it gets one the plugin made, so the game draws it like its own.

```cpp
static void* top_spenders_board() {
    // Made again at most once a second, while the tab is shown.
    game::destroy(spenders_board);
    spenders_board = game::create("mmoLeaderboard");

    void* subscribers = game::singleton("mmoSubscriberManager");

    for (void* subscriber : game::field<game::Objects>(subscribers, "mmoSubscriberManager::subscriber")) {
        void* toon = game::field<void*>(subscriber, "mmoSubscriber::main");
        int spent = spent_by(subscriber);

        if (toon != nullptr && spent >= minimum_spend) {
            register_value(spenders_board, toon, spent);
        }
    }

    return spenders_board;
}
```

3. The board is the game's own class, filled through the game's own `mmoLeaderboard::RegisterValue`, which keeps the top 20 in order. The fields are read by their names, so no offsets. What counts as spent (`spent_by`: subscription fees, other purchases, or both) and `minimum_spend` are the mod's settings, read in `init`:

```cpp
counted = plugin::setting<std::string>("counted");
minimum_spend = plugin::setting<int>("minimum_spend");
```

```cpp
game::in("mmoLeaderboardView::UpdateUI").hook<void(void* view, float seconds)>([](auto original, void* view, float seconds) {
    drawing_spenders = game::field<int>(view, "mmoLeaderboardView::type") == top_spenders;
    original(view, seconds);
    drawing_spenders = false;
});

game::in("mmoLeaderboardView::UpdateUI").call("vsFormatNumber").hook<void*(void* text, int value)>([](auto format_number, void* text, int value) {
    return drawing_spenders ? format_money(text, value) : format_number(text, value);
});
```

4. The numbers are money: while this tab draws, the call that formats them goes to `vsFormatMoney` instead, which uses the currency the player picked. Both return a `vsLocString`, which the game builds where the first parameter points, so the type is written out with that pointer first ([how calls work](#how-calls-to-the-game-work)).

```cpp
game::in("mmoLeaderboardsWindow::OnShow").call("mmoMultiTabView::EnablePage").after([](void* tabs, const game::String&, bool) {
    enable_page(tabs, "{top_spenders_tab}", show_top_spenders);
});
```

5. Right after the window decides about the Duels tab, it decides about this one: shown if the player wants it.

**The checkbox** is `top_spenders_enabled` in `design_features.win`. The Features view fills its checkboxes in `UpdateContents`, and hears their clicks in `UICommand`:

```cpp
game::in("mmoFeaturesView::UpdateContents").after([](void* view) {
    void* checkbox = find_pane(view, "top_spenders_enabled");
    bool researched = leaderboards_researched();

    set_enabled(checkbox, researched);
    set_value(checkbox, researched && show_top_spenders);
});

game::in("mmoFeaturesView::UICommand").after([](bool handled, void* view, void*) {
    void* checkbox = find_pane(view, "top_spenders_enabled");

    if (checkbox != nullptr && leaderboards_researched()) {
        show_top_spenders = game::field<bool>(checkbox, "mmoCheckbox::value");
    }

    return handled;
});
```

Like the game's own feature checkboxes, it can only be ticked once its technology (Leaderboards) is researched. The choice is a `plugin::Remembered`, so it's the same for every saved game. The game keeps its own features (parties, duels) in the saved game; a plugin could do the same with [`game::saved()`](#values-in-saved-games-gamesaved).

The log when it works:

```text
[top_spenders] mmoLeaderboard::Type reads "spenders" as 100
[top_spenders] Hooked mmoLeaderboardSet::GetLeaderboard(mmoLeaderboard::Type)
[top_spenders] Hooked the call at mmoLeaderboardView::UpdateUI(float)+0x134
[top_spenders] Hooked the call at mmoLeaderboardsWindow::OnShow()+0xb7
[top_spenders] The Leaderboards window can show the biggest spenders (counting: lifetime, from 1)
```

## 10. Picked in the game, kept in the save: quest markers

`examples/quest_markers` lets the player pick each quest giver's marker in the game: its shape and its color. The quest giver's info window gets a **Marker** tab with a row of shapes (the game's own, a question mark, a star, a diamond and a speech bubble), a color picker, the color's hex code (typed or copied), sliders for its size and height, and copy, paste and reset. The game's own marker takes a color too. Each quest giver's marker is kept in the saved game.

```text
mod/
  manifest.json
  config.json                        the marker of quest givers with none picked, and its color (set in the manager)
  info_npc.win                       the Marker tab, added to the NPC info window
  i18n/english/quest_markers.vrt     the tab's name and the tooltips
  questmarkers/<shape>.vmb           a marker model: question, star, diamond
  questmarkers/bubble.png            a marker picture
  materials/questmarker.mat          the models' material: the questmarker_v.glsl shader
  materials/questmarker_bubble.mat   the picture's material: its texture and questmarker_sprite_v.glsl
  materials/icon-questmarker_*.mat   the buttons' icons (questmarkers/icon_*.png)
  shaders/questmarker_v.glsl         turns a marker toward the camera and colors it
  shaders/questmarker_sprite_v.glsl  the same for a picture
  native/quest_markers.dll
tools/make_markers.py                makes the models, the picture and the icons
tools/check_shaders.py               compiles the shaders with the game's, for every variant
```

**How the game shows quest markers:** the marker is a model, `QuestGiver.vmb`, loaded once by `mmoCharacterModelManager`. Every quest giver shows it through its own model instance, which `mmoNPC::Generate` (a new quest giver) and `mmoNPC::PostResolve` (a loaded one) make. Every frame `mmoNPC::_PlaceMarker` puts it above the head with `vsModelInstance::SetMatrix(matrix, color)`. The color is the one the game tints the whole quest giver with (red when offline), and the game's `tint` shader mixes each vertex's color toward it.

**Shapes are data.** A shape is a model at `questmarkers/<shape>.vmb`, or a picture's material at `materials/questmarker_<shape>.mat`, plus a button in the tab. A mod adds one by adding those three: its files, and a button in its own `info_npc.win` with `command "MessageTo Window QuestMarker shape <shape>"`. The manager merges that button into the row, and the plugin needs no change. The models are made and painted like the game's own marker: 12 sides, and each part yellow at the top, blending into orange at the bottom, in the game's two colors (`#FDFE0C` and `#C87D1C`). Their shader (`questmarker_v.glsl`, the game's `tint_v.glsl` with two changes) turns the marker to face the camera, and puts the color the player picked in the yellow's place. The orange becomes that color shaded the way the game's yellow becomes its orange: a hue 26.4° warmer, 0.902 as saturated, 0.787 as bright. So a new model painted in those two colors looks like the game's in any color, and exactly like it in the game's yellow.

**The game's own marker in any color** is the same trick with the game's model: the plugin loads `QuestGiver.vmb` again (`vsModel::Load` makes a new model each time) and gives its fragments the mod's material (`vsFragment::SetMaterial`). The shader turns its yellow into the picked color and its orange into that color's shaded version. Nothing of the game's is copied into the mod. In the game's yellow, `#FDFE0C`, the quest giver keeps the game's own instance.

**What the plugin does:**

```cpp
// A quest giver's marker, from the saved game or the manager's default.
Marker marker_of(void* npc) {
    game::Saved saved = game::saved(npc);
    ...
}

// A new or a loaded quest giver shows its own marker model...
game::in("mmoNPC::PostResolve").after([](void* npc, void*) {
    if (!is_games_own(marker_of(npc))) {
        show_marker(npc);
    }
});

// ...in its own color.
game::in("mmoNPC::_PlaceMarker() [clone .part.0]").call("vsModelInstance::SetMatrix")
    .hook<void(void* instance, const void* matrix, const Color* color)>([](auto set_matrix, void* instance, const void* matrix, const Color* color) {
        std::optional<Color> own = placing != nullptr ? color_to_draw(placing) : std::nullopt;

        set_matrix(instance, matrix, own ? &*own : color);
    });

// The tab shows where the Quests tab does: for quest givers only.
game::in("mmoNPCInfoWindow::InitContents").call("mmoMultiView::EnablePage").every()
    .after([](void* tabs, const game::String& page, bool enabled) {
        if (page == "{npcinfo_tab_quests}") {
            enable_page(tabs, "{questmarkers_tab}", enabled);
        }
    });
```

- **The marker model** is loaded and made the way the game makes its own. `vsModel::Load` and `mmoModelRezManager::AddModel` load a model. `_MakeTexturedBadgeModel` (which the game uses for its badges) makes a picture's square. `mmoModelRezManager::MakeInstance` makes the instance, and it replaces the one the quest giver shows. Where a quest giver keeps that instance and its shard, and where a model keeps its fragments, is read at start from the game's own code (`mmoNPC::_PlaceMarker`, `mmoNPC::Generate`, `vsModel::GetLodFragmentCount`), with the bytes checked. The log says `marker at +0x810, shard at +0x170; model levels at +0xa8 +0xb0, fragments at +0x8 +0x10`.
- **The tab** is the game's widgets in `info_npc.win`: toggle buttons in a row (`mmoLayoutView`, `orientation rows`), an `mmoColorPicker` and an `mmoTextEditPane`. Each sends a `QuestMarker …` command that the plugin reads with `game::Record`. The plugin reads the picker's color (`GetColor`, which returns a reference: see [Check the result type](#calling-game-functions-gamefunction)) and leaves the picker alone while it's being dragged.
- **The region's light** (the tint the game passes to `SetMatrix`, from `mmoRegion::GetPropTint`) is mixed over the picked color by its alpha, as the game's shader does for its own marker, so a marker in the game's yellow looks the same as the game's in every region. On screen that yellow is darker than `#FDFE0C` in most places; the hex code is the marker's own color, before the light.
- **Offline and in maintenance**, the game's red and yellow tint wins, as it does for its own marker.
- **Size and height** change the matrix the game passes to `SetMatrix` (the same hook as the color): its axes times the size, its position raised by the height. The sliders are the game's `mmoSlider`, which keeps its value as a step count (at an offset read from `mmoSlider::SetValue_Immediate`) that `mmoSlider::_ConvertToExternal` turns into the number, as the game's own windows read it.
- **Copy** puts `star #FF8800 1.50 0.50` (shape, color, size, height) on the clipboard. **Paste** reads that, or any part of it: just a color, just a shape, or a shape and color without the numbers.

The log when it works:

```text
[quest_markers] Hooked mmoNPC::Generate(mmoCharacterTypeID const&, bool)
[quest_markers] Hooked the call at mmoNPC::_PlaceMarker() [clone .part.0]+0x14e
[quest_markers] Hooked the call at mmoNPCInfoWindow::InitContents()+0x78
[quest_markers] Quest givers get a Marker tab (default marker: game #FDFE0C 1.00 0.00; marker at +0x810, shard at +0x170; model levels at +0xa8 +0xb0, fragments at +0x8 +0x10; slider value at +0x4d0)
Plugin values in saved games: ready (1680 places in the game's code save objects, 1262 kinds of object)
```

## 11. Going deeper

Everything above covers most mods. For the rest, the same machinery is open one level down.

### Hooks that call the game's function themselves: `.hook<Type>`

`before`, `after` and `replace` cover "around" and "instead". When your code needs to decide whether, when and with what arguments the game's function runs, write its type out, and take `auto original` first:

```cpp
game::in("mmoCharacter::EquipWeaponModel").hook<int(void* character, bool show)>([](auto original, void* character, bool show) {
    if (!show) {
        return 0;
    }

    return original(character, true);
});
```

It works on calls too (`.call(...).hook<Type>(...)`), and `game::hook<Type>("name", …)` is the same as `game::in("name").hook<Type>(…)`. Lambdas here may use `auto` for parameters, since the type is written out. They may capture values (`[count]`); don't capture local variables by reference (`[&]`), since the lambda runs long after `init` returns.

### Addresses: game::find, game::Address, places()

```cpp
game::Address equip = game::find("mmoCharacter::EquipWeaponModel");
std::vector<game::Address> compares = game::in("mmoCharacter::EquipWeaponModel").call("std::operator==").every().places();
```

`places()` gives the instructions a `call`, `text` or `number` selection picked. An **`Address`** is a place in the game; `game::find` throws if the name isn't there (`game::try_find` returns an empty one instead):

| Method | What it does |
|---|---|
| `address.read<int>()` | A copy of the value there. Throws if the address can't be read, never crashes. `try_read` returns an empty `std::optional` instead |
| `address.name()`, `address.describe()` | Which function or global it's in: `"mmoCharacter::EquipWeaponModel(bool)"`, and with the offset, `"…+0x61"`. `plugin::log("{}", address)` prints the second |
| `address.matches("48 8D 15 ?? ?? ?? ??")` | Whether the bytes there match a pattern: hex bytes, `??` for any byte |
| `address.expect(pattern)` | Throws unless they match |
| `address.find_text("humanoid")` | The first instruction from here that uses that text |
| `address.find_reference(target)` | The first instruction from here that uses a global, or calls or jumps to a function |
| `address.scan(pattern)` | The first place from here that matches a pattern. `game::scan(pattern)` searches all of the game's code |
| `address.instruction_length()`, `address.next()` | The length of the instruction there, and the one after it |
| `address.target()` | Where the call or jump there goes (the game's function, even if a plugin hooked the call) |

`game::in(address)` works too, as does `game::hook<Type>(address, …)`.

### Bytes: game::patch

```cpp
game::patch(address, { 0xEB });
```

Writes bytes over the game's code or data, logged and undone if `init` fails. You're responsible for checking what's there first (`expect`), since a game update moves code around. Prefer `game::in(...)`: it does the finding and checking for you.

### How calls to the game work

The game was compiled by GCC; your plugin may be compiled by Visual Studio. `mt2loader.hpp` works out from the types how the game passes each argument and result, and does it the game's way:

1. **Big results.** A result bigger than 8 bytes, or any C++ class (`std::string`, `vsVector3D`), is written into room the caller provides, and the pointer to that room goes **first, before the object**. Visual Studio puts it after the object for methods; GCC, and so the game, before.
2. **Strings.** `game::String` has GCC's layout, and uses the game's heap.
3. **Exceptions** never reach the game.

This was checked in the game's own code (`mmoProp::GetFocusPosition`, `mmoPath::GetPositionAtDistance`, `vsSystem::GetTimeAsString`) and in tests that call and hook every kind of result from plugins built by both compilers. Details in LOADER.md §4.4.

**The types:**

- **The game's objects** are pointers: `void*`, or `const void*` for a `const` method. Declare your own struct if you want names for its fields.
- **Numbers, `bool`, pointers and references** as the game has them.
- **`std::string`** is `game::String`, as a reference (`const game::String&`) or a result.
- **The game's small value types** (vectors, colors) as a struct of the same fields, in the same order.
- **Not supported:** a class taken **by value** as a parameter (not a reference or a pointer). How the game passes those hasn't been checked, so it doesn't compile, with a message that says so. `long double` isn't allowed either: it's a different size in the two compilers.

**One case the wrapper can't see:** a plain struct of exactly 1, 2, 4 or 8 bytes is returned in a register, unless the game's class it stands for has a copy constructor or destructor; then it's returned like a big result. When the disassembly shows a result pointer for such a type (it writes to `[rcx]` and returns `rcx`), say so once:

```cpp
template<> inline constexpr bool game::returned_in_memory<Vector2> = true;
```

Some functions are empty in this build (just `ret`, like `mmoModeTitle::SetTitle`): changing those does nothing, because the game has nothing there to run. The disassembly shows it.

## 12. Debugging

- **The log first.** Every plugin start, change and problem is in `mt2loader\loader.log`, with the mod id.
- **A debugger (Visual Studio):** build the **Debug** configuration, start the game, then **Debug > Attach to Process…** and pick `MT2.exe`. Breakpoints in your code work, and you can step through it. (The game itself has no debug information; step over its functions.)
- **Something crashes at startup:** the log's last line names the plugin that was starting. After two crashes in a row with plugins running, the next launch runs without them (the log says so), and the one after tries again.
- **Starting without plugins right now:** hold **Shift** while the game starts. Or create an empty file named `disabled` in `mt2loader\`: the game runs without the loader until you delete it.
- **`mt2sdk check <mod folder>`** checks your mod the way the loader will, without starting the game: the manifest, that each plugin is a 64-bit DLL with an entry point, and that it's made for your game build.

## 13. Releasing your mod

1. Build the **Release** configuration.
2. `mt2sdk check mod` to be sure.
3. Zip the contents of `mod/` (with `manifest.json` at the top of the zip).
4. Say in your mod's description that it needs the MT2 Loader (0.6.0 or newer for `game::in`, the game's objects and settings), and which game builds it works on.

Players add the zip with the mod manager (**Add mod**), or unpack it into the game's mod folder. The manager shows your mod with a **DLL** tag and asks the player to approve native code before it runs.

**After a game update:** the loader won't start your plugin on the new build until you list it (and the loader knows it). Update the loader, test, add the build to `game_builds`, release. If the update changed something your plugin changes, the log says what it couldn't find.

## 14. Rules

These keep players' games safe, and plugin mods trusted.

- **Never write save files**, and never make the game save something it can't load without your plugin. Players must be able to remove your mod and keep playing.
- **Fail safe.** If something you need isn't there or doesn't look as expected, let `init` fail (the API does that for you) or leave that part out. Don't guess addresses.
- **Only touch what your mod is about.** No network access, no files outside your mod folder and `plugin::data_folder()` (except reading the game's), nothing hidden from the log.
- **Don't bundle a hooking library.** Use `game::in` and `game::hook`: they work with other plugins changing the same function, and they show in the log.
- Ship your source if you can. Players are asked to trust native code; open source makes that easy.

## 15. When something goes wrong

**In the log:**

| Message (in part) | Meaning | What to do |
|---|---|---|
| `not started: made for game build X, and this is Y` | `game_builds` doesn't list the running build | Test on it, then add it |
| `No plugin runs: the game build isn't recognized` | The game was updated after this loader | Update the loader |
| `Not started: …` | Your `init` threw: the reason follows | Fix what it names; nothing it did stays |
| `has no call to …`, `has no use of the text …` | That function doesn't have it (or a game update changed it) | Check the function's code, and the name as `mt2sdk find` shows it |
| `has 3 calls to … (at +0x5a, …): pick one` | It's there more than once | Add `.with_text(…)` or `.nth(n)`, or `.every()` |
| `is stored in 1 byte, so it can be from -128 to 127` | The new number doesn't fit where the old one was | Change the code around it with `.hook<Type>` instead |
| `seems to use the length of "…"` | The game uses the text's length next to it | Use a text of the same length, or change the length too |
| `The hook on … failed: …` | Your lambda threw; the game's code ran instead | Fix what it names |
| `Check the declaration of …` | Your lambda or `game::Function` has a different number of parameters than the game's function | Compare with `mt2sdk find` (the object comes first for a method) |
| `it needs MT2 Loader 0.6.0 or newer` | The player's loader is older than your SDK | The player updates the loader |
| `not started: it has no plugin_init` | The DLL has no entry point | Include `<mt2loader.hpp>` and define `void plugin::init()` |
| `not started: Windows couldn't load it … (error 126)` | A DLL your plugin needs is missing | List it in `libraries` and ship it next to the plugin. The template links the C++ runtime in, so it needs none |
| `No game symbol is named '…'` | Typo, or the function doesn't exist in this build | `mt2sdk find` |
| `'…' matches 2 game symbols: …` | Several functions share the name | Add the parameters, as listed |
| `Couldn't hook …: it can't be hooked` | Not a function (a global, say), or too short to hook | Check the name; change the function that calls it |
| `… has no saved field called '…'` | Neither the class nor one it's built on saves a field of that name | `mt2sdk find "Class::s_"` lists them |
| `… is of type int in the game: read it as game::field<int>` | The type in `game::field<…>` isn't the field's | Use the type it names |
| `The game hasn't set up the field … yet` | Read too early | Read it in a lambda the game runs |
| `The game keeps no single …` | That class has no singleton | Check the class name (`mt2sdk find "vsSingleton<"`) |
| `… already has "…"` | `enumeration(…).add` got a word the game knows | Use that word as it is, or pick another |
| `No setting '…': config.json declares no setting '…'` | `plugin::setting` got a key your `config.json` doesn't have (or there's no `config.json`) | Declare it, or fix the key |
| `The setting '…' is a "int" in config.json: read it as plugin::setting<int>` | The type in `plugin::setting<…>` doesn't fit the setting's | Use the type it names |
| `Couldn't keep '…' in the saved game: the game doesn't save this object the usual way` | `game::saved(object).set` on something the game doesn't save (or not a game object) | Keep the value on the object the game saves, or on `game::saved()` |
| `'…' can't be a key for a saved value` | The key has a space or another character keys can't have | Use `A-Z a-z 0-9 _ - .` |
| `Plugin values in saved games aren't available: …` | The loader couldn't find the game's save code (an update?) | `game::saved` stops with that reason; update the loader |
| Nothing from your plugin at all | The mod folder isn't where the game looks, or a copy with the same id started instead | The log's `Looking for plugins in …` line shows the folder; check for duplicates |

**When it doesn't compile:**

| Message (in part) | Meaning |
|---|---|
| `Write the lambda's parameter types … not auto` | `before`, `after` and `replace` read the types from your lambda. Write them, or use `.hook<Type>` |
| `A lambda for .before returns nothing` | `before` can't change the result: use `after`, or `replace` |
| `A lambda for .after gets the function's result first` | Its first parameter is the result, and it returns the result to use |
| `The game's std::string is game::String` | Write `game::String` where the game has `std::string`; a lambda returning text writes `-> game::String` |
| `mt2loader.hpp needs C++20` | The project isn't set to C++20: use the template's `CMakeLists.txt` |
| `In C++, include <mt2loader.hpp> instead` | A file includes `mt2loader.h`, the C layer: include `mt2loader.hpp` |
| `A game function's parameter is a class taken by value` | See [the types](#how-calls-to-the-game-work) |
| `The hook's lambda must take the function's parameters` | The lambda's parameters don't match the type in `.hook<…>` |
| `undefined reference to plugin::init()`, or `unresolved external symbol "void __cdecl plugin::init(void)"` | `void plugin::init()` isn't defined anywhere |

The loader's own messages about startup (proxy, core, safe launches) are explained in [mt2-loader/README.md](mt2-loader/README.md).

## Versions

Underneath `mt2loader.hpp` is a fixed binary interface to the loader (in `mt2loader.h`), and that's what decides compatibility:

- New services are only ever **added**, so a plugin built with an older SDK keeps working with newer loaders.
- `mt2loader.hpp` is compiled into each plugin, so a newer SDK can improve it without affecting plugins already built.
- A plugin built with a newer SDK than the player's loader says so in the log (`it needs MT2 Loader 0.6.0 or newer`) instead of misbehaving.

| Loader | Added |
|---|---|
| 0.3.0 | Plugins, symbols, hooks, memory, sharing (API version 1) |
| 0.4.0 | Code navigation (finding texts, references and patterns in a function), freeing the game's strings. Names with `[abi:cxx11]` are found without it |
| 0.5.0 | `mt2loader.hpp`: plugins are written in C++. `game::Function`, `game::hook`, `game::String`, `game::patch`, `game::field`, undo on a failed start, `mt2sdk find --cpp` |
| 0.6.0 | **`game::in`**: `before`, `after`, `replace`, `returns` for functions and for single calls (`call`, `with_text`, `nth`, `every`), `text(…).becomes`, `number(…).becomes`. Underneath: instruction decoding, function sizes, memory near the game's code, call hooks, and code that runs before a function whatever it returns. Plugins built for 0.4.0 and 0.5.0 keep working |
| 0.8.1 | `game::saved` also keeps values on objects the game saves inside a list's own code (the NPCs) |
| 0.8.0 | **`game::saved`**: the plugin's own values in saved games, on any object the game saves or on the game as a whole. **`game::Record`** reads the game's records (a window's commands). `plugin::setting` reads `color` settings (`"#RRGGBB"`) |
| 0.7.0 | **The game's objects by name:** `game::field<T>(object, "Class::field")` (checked against the game's types, also for fields of the classes it's built on), `game::singleton`, `game::create`, `game::destroy`, `game::Objects`, `game::enumeration` (`value`, `add`). **`plugin::setting`** (the mod's `config.json` settings, as the player set them in the manager), **`plugin::Remembered`** and **`plugin::data_folder`**. Template functions are found without their return type (`"LoadFromRecord<mmoLeaderboard::Type>"`) |

Planned next, in the order of LOADER.md §4.7: game events (every frame, mode changes, the world loaded), sending UI commands, and data-only **features** for mods without code.

## Plain C

The C++ API is built on a C one, `mt2loader.h`, which a plugin in plain C (or another language that makes DLLs) can use directly. It's the loader's fixed interface: a `PluginApi` struct of function pointers, passed to `PLUGIN_EXPORT int plugin_init(const PluginApi* api)`, with every service explained in the header, including the ones `game::in` is built on (`decode`, `function_extent`, `hook_call`, `detour_before`, `allocate_near`). Calling game functions from C follows the rules in [section 10](#how-calls-to-the-game-work), done by hand. `tests/api_plugin.c` in the loader's source uses most of it.

For a C project, take the template, change `CXX` to `C` in `project(...)` and `*.cpp` to `*.c` in its `file(GLOB ...)` line. In C++, including `mt2loader.h` stops with an error that points to `mt2loader.hpp`; define `MT2LOADER_RAW_API` before it if you really want the raw layer.
