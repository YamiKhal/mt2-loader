# Writing plugins for the MT2 Loader

A **plugin** is a small Windows DLL that runs inside MMORPG Tycoon 2. It can find any function or global in the game by name, run its own code before or instead of a game function, and read and change the game's memory. That reaches everything data files can't, like hard-coded limits and missing features.

This guide goes from an empty computer to a working plugin, then covers the whole API. How the loader works inside is in [LOADER.md](LOADER.md); how the mod manager handles plugin mods is in [mt2-modmanager/docs/MODDING.md](mt2-modmanager/docs/MODDING.md#native-plugins-mt2-loader).

**Status (loader 0.3.0, 2026-09-26):** plugins, symbols, hooks, memory and sharing work and are tested on a fake game. On the real game, loading plugins has been tested; hooks haven't yet (test L2 in LOADER.md §5.2). The API may still grow; it won't break (see [Versions](#versions)).

---

## Contents

1. [What you need](#1-what-you-need)
2. [Your first plugin in five minutes](#2-your-first-plugin-in-five-minutes)
3. [The project](#3-the-project)
4. [How a plugin runs](#4-how-a-plugin-runs)
5. [Finding what to change](#5-finding-what-to-change)
6. [The API](#6-the-api)
7. [Calling and hooking game functions](#7-calling-and-hooking-game-functions)
8. [Debugging](#8-debugging)
9. [Releasing your mod](#9-releasing-your-mod)
10. [Rules](#10-rules)
11. [When something goes wrong](#11-when-something-goes-wrong)
12. [Versions](#versions)

---

## 1. What you need

| What | Why | Where |
|---|---|---|
| **MT2 Loader**, installed in the game | Runs plugins | MT2 Mod Manager: the **Install loader** button. Or by hand, from the loader's release zip |
| **The SDK** | The API header, the project template, and `mt2sdk` | `MT2LoaderSDK-<version>.zip`. In this repository, `mt2-loader/dist/sdk` after building the loader |
| **A C compiler for 64-bit Windows** | Builds your DLL | One of the two below |

**Compiler, option A (easiest): Visual Studio Community.** Free. In the Visual Studio Installer, tick the workload **Desktop development with C++**. It includes the compiler, CMake and a debugger. Nothing else to set up.

**Option B: MSYS2 MinGW-w64.** For people who prefer a terminal or VS Code. Install [MSYS2](https://www.msys2.org/), then in its terminal:

```text
pacman -S mingw-w64-x86_64-gcc mingw-w64-x86_64-cmake mingw-w64-x86_64-ninja
```

Any other compiler that makes 64-bit Windows DLLs works too (clang, Zig): plugins and the loader only exchange plain C types, so neither needs the other's runtime.

**Language:** C or C++. The header works in both. The examples are C because game functions are called the same way from either.

## 2. Your first plugin in five minutes

1. **Make the project.** In the SDK folder, open a terminal (in Explorer: type `cmd` in the address bar) and run:

   ```text
   mt2sdk new MyPlugin "My Plugin"
   ```

   This makes the folder `MyPlugin` with a plugin that writes a line to the log when the title screen opens. It fills in the mod id (`myplugin`), the name, and your game's build.

2. **Build it.**
   - Visual Studio: **File > Open > Folder…**, pick `MyPlugin`, wait until the Output window says CMake is done, then **Build > Build All**.
   - MSYS2: `cd MyPlugin`, then `cmake -B build -G Ninja` and `cmake --build build`.

   The DLL lands in `MyPlugin\mod\native\`. The build then copies `mod\` into the game's mod folder, so the game finds it on its next start. (If the build says it can't find the game's mod folder, see [the project](#3-the-project).)

3. **Run it.** Start the game (Steam, or Launch in the mod manager). At the title screen, quit.

4. **Read the log:** `mt2loader\loader.log` in the game folder (in the mod manager: **Tools > Open loader log**):

   ```text
   [myplugin] starting native/myplugin.dll
   Readable names of the game's symbols ready (94 ms)
   [myplugin] Hooked mmoModeTitle::Init()
   [myplugin] Ready on game build 0.30.7
   Plugins: 1 started, from 3 mod folders
   [myplugin] The title screen is opening
   ```

That's the whole loop: change `src\plugin.c`, build, start the game, read the log.

## 3. The project

```text
MyPlugin/
  CMakeLists.txt        the build; the mod id is at the top (MOD_ID)
  include/mt2loader.h   the API: the one header a plugin needs
  src/plugin.c          your code
  mod/                  the mod itself, exactly what players get
    manifest.json
    native/myplugin.dll (made by the build)
```

**`mod/` is the mod.** Anything else your mod needs (textures, data files, a `config.json` for player settings) goes in there too, as for any other mod ([MODDING.md](mt2-modmanager/docs/MODDING.md)).

**Build options** (in Visual Studio: **Project > CMake Settings**, or `-D<option>=<value>` on the command line):

| Option | Default | What it does |
|---|---|---|
| `COPY_TO_GAME` | `ON` | After each build, copy `mod/` to `<game's mod folder>/<mod id>` |
| `GAME_MOD_FOLDER` | found by itself | The game's mod folder: `%APPDATA%\VectorStorm\MMORPG Tycoon 2\<Steam number>\mod`. Set it when you have more than one Steam account on the PC |

The copy fails while the game runs, because Windows locks the DLL. Close the game before building.

**Using the mod manager instead of the copy:** set `COPY_TO_GAME` to `OFF`, add `mod\` with **Tools > Add dev mod…**, and press its refresh button after each build. Don't use both for the same mod: the loader starts a mod id only once, from the first folder it finds.

### manifest.json

```json
{
    "id": "myplugin",
    "name": "My Plugin",
    "version": "1.0.0",
    "author": "",
    "description": "",
    "loader": {
        "plugins": ["native/myplugin.dll"],
        "libraries": [],
        "game_builds": ["0.30.7"]
    }
}
```

| Field | Meaning |
|---|---|
| `id` | 2-24 characters: `a-z`, `0-9`, `_`, starting with a letter. Your plugin's name in the log, and the prefix of anything it shares |
| `loader.plugins` | DLLs the loader starts. Paths inside the mod, with `/`. Each must export `plugin_init` |
| `loader.libraries` | Other DLLs your plugin loads (say, a library you use). Put them next to the plugin: Windows looks there |
| `loader.game_builds` | The game builds you tested on. On any other build, your plugin doesn't start and the log says why. `mt2sdk build` tells you yours |

The other fields are the same as for every mod ([MODDING.md, manifest.json](mt2-modmanager/docs/MODDING.md#manifestjson)).

## 4. How a plugin runs

```c
#include <mt2loader.h>

PLUGIN_EXPORT int plugin_init(const PluginApi* api) {
    api->log(api, "Hello from %s", api->mod_id);

    return PLUGIN_OK;
}
```

1. The game starts. The loader waits until it's past its copy protection (Steam's DRM).
2. The game sets up its files, and just before it looks at its mods, the loader starts the plugins: for each mod folder in order, `plugin_init` of each plugin it lists. **No game system exists yet**: no window, no data, no world. It's the moment to install hooks, not to use the game.
3. When every plugin's `plugin_init` has run, the loader calls `plugin_ready` on the plugins that export it. That's where you look up what other plugins shared.
4. From then on, your code runs whenever the game calls a function you hooked.

Keep `api`: every service is called through it, and it stays valid until the game exits. The usual way is a global:

```c
static const PluginApi* loader;

PLUGIN_EXPORT int plugin_init(const PluginApi* api) {
    loader = api;
    ...
}
```

`plugin_init` returns `PLUGIN_OK` (0), or any other number to have "reported a problem (code N)" logged. The loader carries on either way; your hooks stay installed. Plugins are never unloaded.

## 5. Finding what to change

The game ships with a table of every function and global it has: **about 100,000 names**, like `mmoCharacter::EquipWeaponModel(bool)`. That's what makes this work: you find the right function by its name, and the name stays the same across game updates even when its address moves.

**`mt2sdk find`** searches them. All the words must appear, in any case:

```text
> mt2sdk find equip weapon
mmoCharacter::EquipWeaponModel(bool)    0x1403a1df0
1 found. Use a name as it's written here, with or without its (parameters)

> mt2sdk find costumeeditor setup
mmoCostumeEditorView::_SetupPrefabList()    0x1406b2640
mmoCostumeEditorView::SetupFor(mmoCharacterType*)    0x1406b4500
2 found. Use a name as it's written here, with or without its (parameters)
```

**`mt2sdk symbols`** writes all of them to `game_symbols.txt`, to browse in any editor. The address is where the function sits in `MT2.exe` as disassemblers show it.

**Reading what a function does.** A name tells you where to look; to know what the function does, what it takes and where to hook, read its machine code:

- [Ghidra](https://ghidra-sre.org/) (free): load `MT2.exe`, go to the address from `mt2sdk find` (press G). The decompiler shows C-like code.
- [x64dbg](https://x64dbg.com/) (free): attach to the running game, break on a function, and watch its arguments.
- In this repository, `tools/re/mtre.py dis <name>` prints a function's code with the names of what it calls and the strings it uses.

**The game's own names help a lot:**

| Prefix | What it is |
|---|---|
| `mmo…` | The game: `mmoCharacter`, `mmoCostumeEditorView`, `mmoModeTitle` (the title screen), `mmoGame` |
| `vs…` | The engine, VectorStorm. Mostly [public](https://github.com/vectorstorm/vectorstorm): read the source to see what a `vs` function does |
| `…::Init`, `Deinit`, `Update(float)` | Called when something starts, stops, and every frame |
| `vtable for X` | The table of `X`'s virtual functions |
| `X::s_instance` | The one object of a manager class |

Findings about the game's code so far: [LOADER.md](LOADER.md) §3, [FINDINGS.md](FINDINGS.md), and the `archive/` folder.

## 6. The API

Everything is in `PluginApi`, passed to `plugin_init`. The header, `mt2loader.h`, has the same explanations next to each field.

### Information

| Field | What it is |
|---|---|
| `api->mod_id` | Your mod's id, from `manifest.json` |
| `api->mod_folder` | Your mod's folder, as a wide string (`wchar_t*`), for reading your own files |
| `api->game_build` | The running game build, like `"0.30.7"` |
| `api->loader_version` | The loader's version, like `"0.3.0"` |
| `api->game_base` | Where `MT2.exe` is in memory this launch. `find()` already adds it |
| `api->version`, `api->size` | See [Versions](#versions) |

### log

```c
api->log(api, "Found %d weapons", count);
```

One line in `mt2loader\loader.log`, prefixed with `[your mod id]` and the time. `printf` formatting. The log is replaced every launch; the one before is kept as `loader.previous.log`.

### find, name_of

```c
void* address = api->find(api, "mmoCharacter::EquipWeaponModel");
```

The address of a game function or global in the running game, or `NULL`. Three ways to write the name:

| Written as | Finds |
|---|---|
| `"mmoCharacter::EquipWeaponModel"` | The one function with that name. If there are several (overloads), `NULL`, and the log lists them |
| `"mmoCharacter::EquipWeaponModel(bool)"` | Exactly that one, parameters included |
| `"_ZN12mmoCharacter16EquipWeaponModelEb"` | The raw (mangled) name, as `mt2sdk find --raw` shows it |

Spaces don't matter. `std::string` stands for the long `std::__cxx11::basic_string<char, …>`. When a name isn't found, the log says so and how to search for it.

```c
char name[256];
size_t offset;

if (api->name_of(api, address, name, sizeof name, &offset)) {
    api->log(api, "That's %s+0x%zx", name, offset);
}
```

`name_of` goes the other way: which function an address is in. Handy for logging where something came from.

### hook, hook_address, unhook

See [calling and hooking game functions](#7-calling-and-hooking-game-functions).

### read, write, matches, scan

```c
int* gold = api->find(api, "SomeClass::s_gold");    // a made-up name
int value = 0;

api->read(api, gold, &value, sizeof value);    // false (no crash) if the address isn't readable
value += 100;
api->write(api, gold, &value, sizeof value);   // also works on code: it lifts the protection for the write
```

`write` logs every write with its place (`Wrote 4 bytes at SomeClass::s_gold`), so the log always shows what a plugin changed.

**Byte patterns** check or find machine code: hex bytes, and `??` for "any byte".

```c
unsigned char* function = api->find(api, "mmoCharacter::EquipWeaponModel");

// Before patching code, check it's still what you expect: a game update may have changed it.
if (!api->matches(api, function + 0x53, "48 8D 15 ?? ?? ?? ??")) {
    api->log(api, "EquipWeaponModel changed in this game build; not patching");

    return 1;
}

void* place = api->scan(api, "E8 ?? ?? ?? ?? 84 C0 74 ??");   // first match in the game's code, or NULL
```

Prefer `find` plus `matches` over `scan`: a name survives game updates, a pattern often doesn't.

### share, shared

Plugins can offer things to each other: a function, a table of functions, some data.

```c
// In the plugin that offers it, in plugin_init:
static const WingsApi wings_api = { add_wing, remove_wing };
api->share(api, "wings.api", (void*)&wings_api);

// In a plugin that uses it, in plugin_ready:
const WingsApi* wings = api->shared(api, "wings.api");

if (wings != NULL) {
    wings->add_wing(...);
}
```

Names are global: start them with your mod id. A name can be shared once; a second `share` of it fails and logs who has it. Put the struct you share in a header that you publish with your mod, so others can use it.

### GameString

The game passes text around as C++ `std::string`, which the header describes as `GameString` (the game's compiler lays it out in 32 bytes).

```c
// Reading one the game gives you (vsSingletonManager::GetSingleton(std::string const&) takes the name of a manager):
static void* my_get_singleton(void* manager, const GameString* name) {
    loader->log(loader, "The game asks for %s", game_string_text(name));

    return original_get_singleton(manager, name);
}

// Passing your own text to a function that takes `const std::string&`:
GameString name = game_string_view("P15mmoShardManager");
void* shards = get_singleton(manager, &name);
```

A `game_string_view` only points at your text. The game can read and copy it, but must not keep it, change it or free it: use it only for `const std::string&` parameters.

## 7. Calling and hooking game functions

### The game's functions are ordinary C functions

The game is C++, but on 64-bit Windows a C++ method is called like a C function that takes the object first:

| In the game | As a C function pointer |
|---|---|
| `void mmoModeTitle::Init()` | `void (*)(void* title)` |
| `int mmoCharacter::EquipWeaponModel(bool)` | `int (*)(void* character, bool show)` |
| `void* vsSingletonManager::GetSingleton(const std::string&)` | `void* (*)(void* manager, const GameString* name)` |
| a `static` function or a plain function | its parameters, with no object |

Pointers and references both become pointers; `bool`, `int`, `float` and `double` stay as they are. `float` and `double` go in other registers, but C handles that for you as long as your function pointer has the right types.

**Return types:** check them in the disassembly or decompiler. A function that returns an object by value (a `std::string`, a `vsVector3D`) actually takes a hidden pointer to where the result goes; which parameter that is in this game hasn't been checked yet, so avoid calling or hooking those until it is (LOADER.md tracks it).

Calling one: every game manager, found by its type name (the way the game's own test modes find them):

```c
typedef void* (*GetSingleton)(void* manager, const GameString* name);

void** singleton_manager = api->find(api, "vsSingletonManager::s_instance");
GetSingleton get_singleton = (GetSingleton)api->find(api, "vsSingletonManager::GetSingleton");

// Later, once the game has made its managers (not in plugin_init: none exist yet):
GameString name = game_string_view("P15mmoShardManager");
void* shards = get_singleton(*singleton_manager, &name);
```

Some functions are empty in this build (just `ret`, like `mmoModeTitle::SetTitle`): hooking those does nothing, because the game has nothing there to run. The disassembly shows it.

### Hooking

A hook sends every call of a game function to yours. Yours then decides: run the game's function (through `original`), change its arguments or result, or skip it.

```c
static const PluginApi* loader;
static int (*original_equip)(void* character, bool show);

static int my_equip(void* character, bool show) {
    loader->log(loader, "A character equips a weapon");

    return original_equip(character, show);
}

PLUGIN_EXPORT int plugin_init(const PluginApi* api) {
    loader = api;

    if (!api->hook(api, "mmoCharacter::EquipWeaponModel", (void*)my_equip, (void**)&original_equip)) {
        return 1;
    }

    return PLUGIN_OK;
}
```

- **Same signature.** Your function takes exactly the game function's parameters and returns its type. A mismatch crashes the game, or worse, quietly corrupts something.
- **Always call through `original`**, reading the variable each time (as above). Several plugins can hook the same function: the newest hook runs first, and each one's `original` leads to the next, the last to the game's own. The loader updates `original` when hooks are added or removed.
- **One function per hook:** don't hook two game functions with the same function of yours.
- `hook_address` does the same for an address (from `find`, `scan`, or a vtable).
- `unhook(api, my_equip)` takes your hook out again; other plugins' hooks on the same function keep working.
- The log shows every hook: `[yourmod] Hooked mmoCharacter::EquipWeaponModel(bool) (2 hooks on it now; this one runs first)`.

**Keep hooks fast** when the game calls them often (anything with `Update` or `Draw` in its name runs every frame). The game calls most functions on its main thread; if you share data with other threads you start, protect it yourself.

## 8. Debugging

- **The log first.** Every plugin start, hook, write and problem is in `mt2loader\loader.log`, with the mod id.
- **A debugger (Visual Studio):** build the **Debug** configuration, start the game, then **Debug > Attach to Process…** and pick `MT2.exe`. Breakpoints in your code work, and you can step through it. (The game itself has no debug information; step over its functions.)
- **Something crashes at startup:** the log's last line names the plugin that was starting. After two crashes in a row with plugins running, the next launch runs without them (the log says so), and the one after tries again.
- **Starting without plugins right now:** hold **Shift** while the game starts. Or create an empty file named `disabled` in `mt2loader\`: the game runs without the loader until you delete it.
- **`mt2sdk check <mod folder>`** checks your mod the way the loader will, without starting the game: the manifest, that each plugin is a 64-bit DLL exporting `plugin_init`, and that it's made for your game build.

## 9. Releasing your mod

1. Build the **Release** configuration.
2. `mt2sdk check mod` to be sure.
3. Zip the contents of `mod/` (with `manifest.json` at the top of the zip).
4. Say in your mod's description that it needs the MT2 Loader, and which game builds it works on.

Players add the zip with the mod manager (**Add mod**), or unpack it into the game's mod folder. The manager shows your mod with a **DLL** tag and asks the player to approve native code before it runs.

**After a game update:** the loader won't start your plugin on the new build until you list it (and the loader knows it). Update the loader, test, add the build to `game_builds`, release. If the update moved or changed a function you use, `find` or `matches` tells you in the log.

## 10. Rules

These keep players' games safe, and plugin mods trusted.

- **Never write save files**, and never make the game save something it can't load without your plugin. Players must be able to remove your mod and keep playing.
- **Fail safe.** If a function you need isn't found or doesn't look as expected, log it and leave that part out. Don't guess addresses.
- **Only touch what your mod is about.** No network access, no files outside your mod folder (except reading the game's), nothing hidden from the log.
- **Don't bundle a hooking library.** Use `hook`: it works with other plugins hooking the same function, and it shows in the log.
- Ship your source if you can. Players are asked to trust native code; open source makes that easy.

## 11. When something goes wrong

| In the log | Meaning | What to do |
|---|---|---|
| `not started: made for game build X, and this is Y` | `game_builds` doesn't list the running build | Test on it, then add it |
| `No plugin runs: the game build isn't recognized` | The game was updated after this loader | Update the loader |
| `not started: it has no plugin_init` | The DLL doesn't export it | Declare it with `PLUGIN_EXPORT` (C++: the macro includes `extern "C"`) |
| `not started: Windows couldn't load it … (error 126)` | A DLL your plugin needs is missing | List it in `libraries` and ship it next to the plugin. Visual Studio: the template links the C runtime in, so it needs none |
| `No game symbol is named '…'` | Typo, or the function doesn't exist in this build | `mt2sdk find` |
| `'…' matches 2 game symbols: …` | Several functions share the name | Add the parameters, as listed |
| `Couldn't hook …: it can't be hooked` | Not a function (a global, say), or too short to hook | Check the name; hook the function that calls it |
| Nothing from your plugin at all | The mod folder isn't where the game looks, or a copy with the same id started instead | The log's `Looking for plugins in …` line shows the folder; check for duplicates |

The loader's own messages about startup (proxy, core, safe launches) are explained in [mt2-loader/README.md](mt2-loader/README.md).

## Versions

`api->version` is the API version of the running loader, `LOADER_API_VERSION` the one your header describes.

- New services are only ever **added at the end** of `PluginApi`, so a plugin built with an older header keeps working with newer loaders.
- A plugin built with a newer header can check that a field exists before using it: `api->size > offsetof(PluginApi, field)`.
- If something ever has to change meaning, `LOADER_API_VERSION` goes up, and the loader keeps giving old plugins what they expect.

| API version | Loader | Added |
|---|---|---|
| 1 | 0.3.0 | Information, `log`, `find`, `name_of`, `hook`, `hook_address`, `unhook`, `read`, `write`, `matches`, `scan`, `share`, `shared`, `plugin_ready`, `GameString` |

Planned next, in the order of LOADER.md §4.7: game events (every frame, mode changes, the world loaded), reaching the game's managers by name, the game's reflection (reading and changing any registered property of any object by name), sending UI commands, and data-only **features** for mods without code.
