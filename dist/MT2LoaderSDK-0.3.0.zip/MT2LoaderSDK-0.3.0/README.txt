MT2 Loader SDK 0.3.0
Everything needed to write native plugins for MMORPG Tycoon 2. The full guide is LOADER_MODDING.md.

START A PLUGIN
1. Install Visual Studio Community (free) with "Desktop development with C++".
   (Or MSYS2's MinGW-w64, or any compiler that makes 64-bit Windows DLLs.)
2. In this folder: mt2sdk new MyPlugin "My Plugin"
3. In Visual Studio: File > Open > Folder, pick MyPlugin, then Build > Build All.
   The DLL goes into MyPlugin\mod\native, and mod\ is copied into the game's mod folder.
4. Start the game. mt2loader\loader.log in the game folder shows your plugin's lines.

FIND WHAT TO CHANGE
  mt2sdk find <words>     search the game's functions and globals by name
  mt2sdk symbols          write all of them to game_symbols.txt
  mt2sdk check <mod>      check a plugin mod the way the loader will
  mt2sdk build            which game build you have, and whether this SDK knows it

WHAT'S HERE
  mt2sdk.exe              the tool above
  include\mt2loader.h     the plugin API: the one file a plugin includes
  template\               what "mt2sdk new" copies
  examples\               small plugins to start from

The game needs the MT2 Loader installed to run plugins (MT2 Mod Manager has a button for it).
