#include <mt2loader.h>


PLUGIN_EXPORT int plugin_init(const PluginApi* api) {
    api->log(api, "Hello from %s: game build %s, loader %s", api->mod_id, api->game_build, api->loader_version);

    return PLUGIN_OK;
}
