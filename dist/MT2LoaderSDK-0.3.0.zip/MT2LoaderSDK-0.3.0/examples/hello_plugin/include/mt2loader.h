/*
    MT2 Loader plugin API: the only file a plugin needs. Copy it into your project.

    A plugin is a 64-bit Windows DLL that exports plugin_init. The loader calls it once, early in startup
    (while the game looks for its mods, before any game system exists), with a PluginApi that stays valid
    until the game exits. Keep the pointer: every service is called through it.

        #include "mt2loader.h"

        PLUGIN_EXPORT int plugin_init(const PluginApi* api) {
            api->log(api, "Hello from %s", api->mod_id);

            return PLUGIN_OK;
        }

    Works with any C or C++ compiler that makes 64-bit Windows DLLs (Visual Studio, MinGW-w64, clang).
    Only plain C types cross between plugin and loader, so the plugin may use any C runtime.

    Full guide: LOADER_MODDING.md
*/
#ifndef MT2LOADER_H
#define MT2LOADER_H

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>
#include <wchar.h>

// The API this header describes. A loader gives plugins every API version up to its own.
#define LOADER_API_VERSION 1

#define PLUGIN_OK 0

#ifdef __cplusplus
#define PLUGIN_EXPORT extern "C" __declspec(dllexport)
#else
#define PLUGIN_EXPORT __declspec(dllexport)
#endif

typedef struct PluginApi PluginApi;

struct PluginApi {
    // Size of this struct as the running loader knows it. A field exists if its offset is below size.
    uint32_t size;
    // LOADER_API_VERSION of the running loader.
    uint32_t version;

    const char* loader_version;
    // The game build, as named in manifest.json's "game_builds", like "0.30.7".
    const char* game_build;
    const char* mod_id;
    // Where the mod's folder is, for reading its own files.
    const wchar_t* mod_folder;
    // Where MT2.exe is loaded. Game addresses move every launch; find() already adds this.
    void* game_base;

    // Writes one line to the loader's log (mt2loader\loader.log), prefixed with the mod id. printf formatting.
    void (*log)(const PluginApi* api, const char* format, ...);

    /*
        Game symbols: every function and global of MT2.exe, by name. Returns its address in the running game,
        or NULL (and logs why) when there's no such symbol or the name is ambiguous.

        Names can be written three ways:
            "mmoCharacter::EquipWeaponModel"          readable, without parameters (must match only one symbol)
            "mmoCharacter::EquipWeaponModel(bool)"    readable, with parameters (for overloaded functions)
            "_ZN12mmoCharacter16EquipWeaponModelEb"   the raw (mangled) name
        Spaces don't matter, and std::string can stand for std::__cxx11::basic_string<char, ...>.
        mt2sdk find <text> lists the names.
    */
    void* (*find)(const PluginApi* api, const char* name);

    // Readable name of the symbol that contains address, plus the offset into it. Returns false if none.
    bool (*name_of)(const PluginApi* api, const void* address, char* name, size_t name_size, size_t* offset);

    /*
        Hooks: replace a game function with your own. Your function gets the same arguments (for a method,
        the object comes first) and returns the same type. Call *original to run the game's function
        from yours, or skip it. Several plugins can hook one function: the last hook is called first,
        and each one's original leads to the one before it.

            static int (*original_equip)(void* character, bool show);

            static int my_equip(void* character, bool show) {
                return original_equip(character, true);
            }

            api->hook(api, "mmoCharacter::EquipWeaponModel", (void*)my_equip, (void**)&original_equip);

        hook takes a name as find() does; hook_address takes an address. Both return false and log why
        if it can't be done. Always call through *original: the loader updates it when hooks change.
    */
    bool (*hook)(const PluginApi* api, const char* name, void* detour, void** original);
    bool (*hook_address)(const PluginApi* api, void* target, void* detour, void** original);
    // Takes one of your hooks out again. Other plugins' hooks on the same function keep working.
    bool (*unhook)(const PluginApi* api, void* detour);

    /*
        Memory. Patterns are hex bytes with ?? for any byte: "48 8B ?? 10 E8".
        read never crashes on a bad address: it returns false. write also works on code (it lifts the
        page protection for the write) and logs each patch.
    */
    bool (*read)(const PluginApi* api, const void* address, void* buffer, size_t size);
    bool (*write)(const PluginApi* api, void* address, const void* bytes, size_t size);
    bool (*matches)(const PluginApi* api, const void* address, const char* pattern);
    // First place in the game's code (.text) that matches pattern, or NULL.
    void* (*scan)(const PluginApi* api, const char* pattern);

    /*
        Sharing between plugins: publish a pointer (a function, a struct of functions, data) under a name,
        so other plugins can use it. Names are global: prefix them with your mod id, like "wings.api".
        Share in plugin_init; look up in plugin_ready, when every plugin has shared what it offers.
    */
    bool (*share)(const PluginApi* api, const char* name, void* pointer);
    void* (*shared)(const PluginApi* api, const char* name);
};

/*
    The game's std::string, laid out as the game's compiler (GCC) makes it: 32 bytes. Many game functions
    take or return one. game_string_text reads one. game_string_view wraps your text so it can be passed
    to a game function that takes `const std::string&`; the game can read and copy it, and nothing else.
*/
typedef struct GameString {
    char* data;
    size_t length;
    union {
        char local[16];
        size_t capacity;
    };
} GameString;

static inline const char* game_string_text(const GameString* string) {
    return string->data;
}

static inline GameString game_string_view(const char* text) {
    GameString string;
    size_t length = 0;

    while (text[length] != '\0') {
        length++;
    }

    string.data = (char*)text;
    string.length = length;
    string.capacity = length;

    return string;
}

// What a plugin exports. Return PLUGIN_OK, or any other number to have it logged as a problem.
typedef int (*PluginInitFunction)(const PluginApi* api);

// Optional export, PLUGIN_EXPORT void plugin_ready(const PluginApi* api): called once every plugin's
// plugin_init has run, still before the game loads its mods.
typedef void (*PluginReadyFunction)(const PluginApi* api);

#endif
