#include <mt2loader.h>

static const PluginApi* loader;
static void (*original_title_init)(void* title);


// Runs instead of mmoModeTitle::Init, which the game calls when the title screen opens.
static void title_init(void* title) {
    loader->log(loader, "The title screen is opening");

    original_title_init(title);
}


PLUGIN_EXPORT int plugin_init(const PluginApi* api) {
    loader = api;

    if (!api->hook(api, "mmoModeTitle::Init", (void*)title_init, (void**)&original_title_init)) {
        return 1;
    }

    api->log(api, "Ready on game build %s", api->game_build);

    return PLUGIN_OK;
}
